function [totalElapsedTime] = UpdateRunTimeClock( totalElapsedTime,timestep)
%UpdateRunTimeClock Summary of this function goes here
%   Detailed explanation goes here
%
%
%Copyright EBG: 
%Creative Commons 
%Attribution-NonCommercial-ShareAlike 
%3.0 Unported
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

totalElapsedTime=totalElapsedTime+timestep;
    
end
